<style>
  input[type="radio"] {
  display: none; /* Hide the radio buttons */
}

/* Styles for labels */
label {
  cursor: pointer;
  padding: 5px 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  margin-right: 10px;
}

/* Styles for radio buttons when they are checked */
input[type="radio"]:checked + label {
  background-color: #4CAF50; /* Change background color */
  color: #fff; /* Change text color */
}
</style>

<div>
    
<input type="radio" name="options" id="option1">
<label for="option1">Option 1</label>

<input type="radio" name="options" id="option2">
<label for="option2">Option 2</label>

    
</div>